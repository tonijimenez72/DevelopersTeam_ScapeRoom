package main;

import controller.EscapeRoomController;
import model.Clue;
import model.Decoration;
import model.Room;
import enums.*;
import service.EscapeRoomService;
import service.EscapeRoomServiceImpl;

public class Main {
    public static void main(String[] args) {
        EscapeRoomService escapeRoomService = new EscapeRoomServiceImpl();
        EscapeRoomController escapeRoomController = new EscapeRoomController(escapeRoomService);
        Clue clue = new Clue("The last letter received", 20,Theme.MISTERY);

        escapeRoomController.createEscapeRoom("Escape from IT Academy");

        escapeRoomController.showEscapeRoomInventory(true);
        escapeRoomController.showInventoryValue();

        escapeRoomController.addClue(clue);
        escapeRoomController.addClue(new Clue("The last letter received", 20,Theme.MISTERY));

        escapeRoomController.addDecoration(new Decoration("Red lamp", 10, "lamp"));
        escapeRoomController.addDecoration(new Decoration("Blue lamp", 10, "lamp"));

        escapeRoomController.addRoom(new Room("The Old Library of Arkham", Theme.MISTERY, DifficultyLevel.MEDIUM, 50.0));
        escapeRoomController.addRoom(new Room("The New Library of Arkham", Theme.MISTERY, DifficultyLevel.MEDIUM, 50.0));

        clue.setAvailable(false);

        escapeRoomController.showEscapeRoomInventory(true);
        escapeRoomController.showInventoryValue();
    }
}