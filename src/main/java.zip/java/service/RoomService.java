package service;

import model.Clue;
import model.Decoration;
import model.Room;

import java.util.List;

public interface RoomService {
    void addRoom(Room room);
    List<Room> getAllRooms();
    Room getRoomById(int id);
    void updateRoomAvailability(int id, boolean available);
    void removeRoom(int id);
    void addClue(Room room, Clue clue);
    void addDecoration(Room room, Decoration decoration);
}