package service;

import model.Clue;
import model.Decoration;
import model.Room;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RoomServiceImpl implements RoomService{
    private final List<Room> rooms;

    public RoomServiceImpl() {
        this.rooms = new ArrayList<>();
    }

    @Override
    public void addRoom(Room room) {
        if (room == null) {
            throw new IllegalArgumentException("Room cannot be null.");
        }
        rooms.add(room);
        System.out.println("Room added: " + room.getName());
    }

    @Override
    public List<Room> getAllRooms() {
        return new ArrayList<>(rooms); // Return a copy to avoid external modification
    }

    @Override
    public Room getRoomById(int id) {
        Optional<Room> room = rooms.stream().filter(r -> r.getId() == id).findFirst();
        return room.orElseThrow(() -> new IllegalArgumentException("Room with ID " + id + " not found."));
    }

    @Override
    public void updateRoomAvailability(int id, boolean available) {
        Room room = getRoomById(id);
        room.setAvailable(available);
        System.out.println("Room availability updated: " + room.getName() + " -> " + (available ? "Available" : "Unavailable"));
    }

    @Override
    public void removeRoom(int id) {
        Room room = getRoomById(id);
        rooms.remove(room);
        System.out.println("Room removed: " + room.getName());
    }
    @Override
    public void addClue(Room room, Clue clue) {
        if (!clue.isAvailable()) {
            System.out.println("Clue is unavailable.");
            return;
        }
        room.getClues().add(clue);
        System.out.println("Clue added to room.");
    }

    @Override
    public void addDecoration(Room room, Decoration decoration) {
        if (!decoration.isAvailable()) {
            System.out.println("Decoration is unavailable.");
            return;
        }
        room.getDecorations().add(decoration);
        System.out.println("Decoration added to room.");
    }
}